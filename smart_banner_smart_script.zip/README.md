# AppsFlyer Smart Banner Test Website

A simple website to test AppsFlyer Smart Banner functionality. This website includes the Smart Banner SDK and provides interactive controls for testing banner behavior.

## Features

- ✅ AppsFlyer Smart Banner SDK integration
- ✅ Interactive banner controls (show/hide/update parameters)
- ✅ Mobile device detection
- ✅ Keyboard shortcuts for testing
- ✅ Responsive design
- ✅ Notification system for user feedback
- ✅ Custom font support for banners

## Setup Instructions

### 1. Get Your AppsFlyer Web Key

1. Log into your AppsFlyer dashboard
2. Go to the **Website workplace**
3. Create a new Website workplace if you don't have one
4. Copy your **Web key** from the dashboard

### 2. Update the Website

1. Open `index.html` in a text editor
2. Find this line in the script:
   ```javascript
   banners: {key: "YOUR_WEB_KEY"}
   ```
3. Replace `YOUR_WEB_KEY` with your actual AppsFlyer Web Key

### 3. Create a Smart Banner

1. In your AppsFlyer dashboard, go to **Smart Banners**
2. Create a new Smart Banner
3. Configure your banner settings (design, text, etc.)
4. Save the banner

### 4. Test the Website

1. Open `index.html` in a web browser
2. Use browser dev tools to simulate a mobile device
3. The Smart Banner should appear at the bottom of the page

## Testing Features

### Interactive Controls

- **Show Banner**: Manually trigger banner display
- **Hide Banner**: Remove the banner from the page
- **Update Parameters**: Add custom parameters to the OneLink URL

### Keyboard Shortcuts

- `Ctrl/Cmd + 1`: Show Banner
- `Ctrl/Cmd + 2`: Hide Banner  
- `Ctrl/Cmd + 3`: Update Parameters

### Mobile Testing

Smart Banners are designed for mobile devices. To test:

1. **Desktop**: Use browser dev tools to simulate mobile
2. **Mobile**: Open the website directly on a mobile device
3. **Tablet**: Test on iPad or Android tablet

## File Structure

```
├── index.html          # Main HTML file with Smart Banner SDK
├── styles.css          # CSS styles for the website
├── script.js           # JavaScript with banner control functions
└── README.md           # This file
```

## Smart Banner SDK Functions

### showBanner()
```javascript
AF('banners', 'showBanner', {
    bannerContainerQuery: "#my-container",  // Optional
    bannerZIndex: 1000,                   // Optional
    additionalParams: {                    // Optional
        deep_link_value: "apples",
        deep_link_sub1: "22"
    }
});
```

### hideBanner()
```javascript
AF('banners', 'hideBanner');
```

### updateParams()
```javascript
AF('banners', 'updateParams', {
    deep_link_value: "new_param",
    deep_link_sub1: "demo",
    af_adset: "smart_banner_test"
});
```

## Customization

### Custom Fonts

To use custom fonts in your Smart Banner, add this CSS:

```css
[data-af-custom-fonts="af-creatives-text"] {
    font-family: YOUR-CUSTOM-FONT !important;
}
```

### Banner Styling

The Smart Banner automatically handles styling, but you can customize:

- Z-index positioning
- Container placement
- Custom parameters for deep linking

## Troubleshooting

### Banner Not Showing

1. Check that your Web Key is correct
2. Ensure you're testing on a mobile device or mobile simulation
3. Check browser console for errors
4. Verify your Smart Banner is active in AppsFlyer dashboard

### Console Errors

Common issues:
- `AF is not defined`: SDK not loaded properly
- `Invalid web key`: Check your AppsFlyer Web Key
- `Banner not found`: Smart Banner not created in dashboard

### Testing Tips

1. **Clear browser cache** when testing changes
2. **Use incognito mode** to avoid cached banners
3. **Test on real devices** when possible
4. **Check network tab** for SDK loading issues

## AppsFlyer Documentation

- [Smart Banner v2 Documentation](https://dev.appsflyer.com/hc/docs/dl_smart_banner_v2)
- [Smart Banner Marketing Guide](https://support.appsflyer.com/hc/en-us/articles/360000764837-Smart-Banners-mobile-web-to-app-for-marketers)

## Browser Support

- Chrome (recommended for testing)
- Safari
- Firefox
- Edge

## License

This is a test website for AppsFlyer Smart Banner functionality. Use for testing and development purposes only. 